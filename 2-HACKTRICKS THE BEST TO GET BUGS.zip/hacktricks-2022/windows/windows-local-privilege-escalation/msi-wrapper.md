# MSI Wrapper

Download the free version app from [https://www.exemsi.com/documentation/getting-started/](https://www.exemsi.com/download/), execute it and wrap the "malicious" binary on it.\
Note that you can wrap a "**.bat**" if you **just** want to **execute** **command lines (instead of cmd.exe select the .bat file)**

![](<../../.gitbook/assets/image (304).png>)

And this is the most important part of the configuration:

![](<../../.gitbook/assets/image (305).png>)

![](<../../.gitbook/assets/image (308).png>)

![](<../../.gitbook/assets/image (310).png>)

(Please, note that if you try to pack your own binary you will be able to modify these values)

From here just click on **next buttons** and the last **build button and your installer/wrapper will be generated.**
