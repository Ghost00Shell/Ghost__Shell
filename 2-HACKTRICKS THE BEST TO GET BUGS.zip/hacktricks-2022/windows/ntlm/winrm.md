# WinRM

For information about [**WinRM read this page**](../../pentesting/5985-5986-pentesting-winrm.md).
