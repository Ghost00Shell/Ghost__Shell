# Other Big References

{% embed url="https://highon.coffee/blog/penetration-testing-tools-cheat-sheet/#python-tty-shell-trick" %}

{% embed url="https://hausec.com/pentesting-cheatsheet/#_Toc475368982" %}

{% embed url="https://anhtai.me/pentesting-cheatsheet/" %}

{% embed url="https://bitvijays.github.io/LFF-IPS-P2-VulnerabilityAnalysis.html" %}

{% embed url="https://ired.team/offensive-security-experiments/offensive-security-cheetsheets" %}

{% embed url="http://www.lifeoverpentest.com/2018/02/enumeration-cheat-sheet-for-windows.html" %}

{% embed url="https://chryzsh.gitbooks.io/pentestbook/basics_of_windows.html" %}

{% embed url="https://github.com/wwong99/pentest-notes/blob/master/oscp_resources/OSCP-Survival-Guide.md" %}

{% embed url="https://anhtai.me/oscp-fun-guide/" %}

