# RC4 - Encrypt\&Decrypt

If you can somehow encrypt a plaintext using a RC4**,** you can decrypt any content encrypted by that RC4(using the same password) just using the encryption function.

If you can encrypt a known plaintext you can also extract the password. More references can be found in the HTB Kryptos machine:

{% embed url="https://0xrick.github.io/hack-the-box/kryptos/" %}

{% embed url="https://0xrick.github.io/hack-the-box/kryptos/" %}

****

