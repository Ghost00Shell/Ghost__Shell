# Learning Pages and VMs

## https://tryhackme.com/

Tryhackme is a platform with virtual machines that need to be solved through walkthroughs, which is very good for beginners and normal CTFs where you self must hack into the machines.



## https://www.root-me.org/   

Rootme is another page for online hosted virtual machines to hack. 



## https://www.vulnhub.com/ 

Vulnhub has machines to download and then to hack



## https://www.hackthebox.eu/ https://academy.hackthebox.eu/catalogue 

Hackthebox has online machines to hack, but there are very limited in the free version.

Recently the launched their academy, but it is a bit more expensive than for example tryhackme and has less.



## https://hack.me/

This site seems to be a community platform



## https://www.hacker101.com/

Free and smale site with videos and CTFs


## https://crackmes.one/

This site has a lot of binarys for forensic learning.

## https://overthewire.org/wargames/

The wargames offered by the OverTheWire community can help you to learn and practice security concepts in the form of fun-filled games.
 Perfect for beginners.

## https://www.hackthissite.org/missions/basic/ 

## https://attackdefense.com/
